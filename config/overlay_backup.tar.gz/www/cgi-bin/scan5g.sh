#!/bin/sh
echo "Content-type: text/html; charset=UTF-8"
echo ""

# ---- 1. حفظ حالة الاتصال الحالية ----
CURRENT_SSID=$(iwinfo radio1 info 2>/dev/null | grep "ESSID:" | sed 's/.*ESSID: "//;s/"//')
CURRENT_KEY=$(uci -q get wireless.@wifi-iface[1].key)

# ---- 2. تحرير الواجهة مؤقتاً للمسح ----
if [ -n "$CURRENT_SSID" ]; then
    # حفظ الوضع الحالي
    uci -q set wireless.@wifi-iface[1].mode='ap'
    uci -q set wireless.@wifi-iface[1].ssid="scan_temp_ssid"
    uci commit wireless
    wifi reload
    sleep 2
fi

# ---- 3. إجراء المسح وعرض النتائج ----
iw dev phy1-ap0 scan > /dev/null 2>&1
sleep 6

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>"
echo "body{font-family:sans-serif;direction:rtl;padding:15px;background:#fff;}"
echo "h3{color:#5e72e4;text-align:center;}"
echo "table{width:100%;border-collapse:collapse;font-size:13px;}"
echo "th{background:#5e72e4;color:#fff;padding:8px;}"
echo "td{padding:6px;border-bottom:1px solid #ddd;text-align:center;}"
echo "button{background:#5e72e4;color:#fff;border:none;padding:5px 12px;border-radius:3px;cursor:pointer;}"
echo ".close-btn{background:#999;}"
echo "</style></head><body><h3>البحث عن شبكات 5G</h3><table>"
echo "<tr><th>Signal</th><th>SSID</th><th>Channel</th><th>Mode</th><th>BSSID</th><th>Encryption</th><th></th></tr>"

iwinfo radio1 scan 2>/dev/null | awk '
/^Cell/ { if (ssid) print_row(); ssid=""; signal=""; channel=""; mode=""; bssid=""; enc="None" }
/ESSID:/ { gsub(/.*ESSID: "/,""); gsub(/"$/,""); ssid=$0 }
/Signal:/ { gsub(/.*Signal: /,""); gsub(/ dBm.*/,""); signal=$0 }
/Channel:/ { gsub(/.*Channel: /,""); gsub(/ .*/,""); channel=$0 }
/Mode:/ { gsub(/.*Mode: /,""); gsub(/ .*/,""); mode=$0 }
/Address:/ { gsub(/.*Address: /,""); bssid=$0 }
/Encryption:/ { gsub(/.*Encryption: /,""); enc=$0 }
END { if (ssid) print_row() }
function print_row() {
    printf "<tr><td>%s dBm</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><button onclick=\"opener.document.querySelector('\''input[id\\$=special_ssid]'\'').value='\''%s'\'';window.close();\">اختيار</button></td></tr>\n", signal, ssid, channel, mode, bssid, enc, ssid
}'

echo "</table><br><center><button class='close-btn' onclick='window.close()'>إغلاق</button></center></body></html>"

# ---- 4. استعادة الاتصال السابق بعد إغلاق النافذة ----
if [ -n "$CURRENT_SSID" ]; then
    uci -q set wireless.@wifi-iface[1].mode='sta'
    uci -q set wireless.@wifi-iface[1].ssid="$CURRENT_SSID"
    [ -n "$CURRENT_KEY" ] && uci -q set wireless.@wifi-iface[1].key="$CURRENT_KEY"
    uci commit wireless
    wifi reload
fi
