'use strict';'require view';'require dom';'require poll';'require fs';'require network';
document.querySelector('head').appendChild(E('link', {
	'rel': 'stylesheet',
	'type': 'text/css',
	'href': L.resource('view/maindash/custom.css')
}));


function invokeIncludesLoad(includes){var tasks=[],has_load=false;for(var i=0;i<includes.length;i++){if(typeof(includes[i].load)=='function'){tasks.push(includes[i].load().catch(L.bind(function(){this.failed=true;},includes[i])));has_load=true;}
else{tasks.push(null);}}
return has_load?Promise.all(tasks):Promise.resolve(null);}
function startPolling(includes,containers){var step=function(){return network.flushCache().then(function(){return invokeIncludesLoad(includes);}).then(function(results){for(var i=0;i<includes.length;i++){var content=null;if(includes[i].failed)
continue;if(typeof(includes[i].render)=='function')
content=includes[i].render(results?results[i]:null);else if(includes[i].content!=null)
content=includes[i].content;if(content!=null){containers[i].parentNode.style.display='';containers[i].parentNode.classList.add('fade-in');dom.content(containers[i],content);}}
var ssi=document.querySelector('div.includes');if(ssi){ssi.style.display='';ssi.classList.add('fade-in');}});};return step().then(function(){poll.add(step);});}
return view.extend({load:function(){return L.resolveDefault(fs.list('/www'+L.resource('view/maindash/include')),[]).then(function(entries){return Promise.all(entries.filter(function(e){return(e.type=='file'&&e.name.match(/\.js$/));}).map(function(e){return'view.maindash.include.'+e.name.replace(/\.js$/,'');}).sort().map(function(n){return L.require(n);}));});},render:function(includes){// ===== أيقونة البرمجة السريعة =====
var bannerDiv = E('div', { style: 'text-align: center; margin: 10px 0 20px 0;' }, [
    E('a', {
        href: '/cgi-bin/luci/admin/wizard',
        style: 'display: block; background: linear-gradient(135deg, #4facfe, #00f2fe); color: #fff; text-shadow: 0 0 10px rgba(255,255,255,0.4); padding: 14px 20px; border-radius: 10px; text-decoration: none; font-weight: 700; animation: moonShake 4s infinite, moonPulse 3s infinite;'
    }, [
        E('span', { style: 'font-size: 17px;' }, '⚡ البرمجة السريعة'),
        E('span', { style: 'font-size: 11px; opacity: 0.9; margin-right: 8px;' }, '- إعداد سريع للراوتر'),
        E('span', { style: 'float: left; font-size: 16px;' }, '❯')
    ])
]);

// أنماط الحركات
var styleSheet = document.createElement("style");
styleSheet.textContent = '@keyframes moonShake{0%,100%{transform:translateX(0)}1%{transform:translateX(-4px)}2%{transform:translateX(4px)}3%{transform:translateX(-4px)}4%{transform:translateX(4px)}5%{transform:translateX(0)}}@keyframes moonPulse{0%,100%{background:linear-gradient(135deg,#4facfe,#00f2fe);box-shadow:0 0 20px rgba(79,172,254,0.6),0 0 40px rgba(0,242,254,0.3)}50%{background:linear-gradient(135deg,#1a3a4a,#0d7377);box-shadow:0 0 30px rgba(13,115,119,0.9),0 0 60px rgba(13,115,119,0.6),0 0 80px rgba(26,58,74,0.4)}}';
document.head.appendChild(styleSheet);
// ===== نهاية الأيقونة =====

var rv=E([bannerDiv]),containers=[];for(var i=0;i<includes.length;i++){var title=null;if(includes[i].title!=null)
title=includes[i].title;else
title=String(includes[i]).replace(/^\[ViewmaindashInclude\d+_(.+)Class\]$/,function(m,n){return n.replace(/(^|_)(.)/g,function(m,s,c){return(s?' ':'')+c.toUpperCase()})});var container=E('div');rv.appendChild(E('div',{'class':'cbi-section','style':'display:none'},[title!=''?E('h3',title):'',container]));containers.push(container);}
return startPolling(includes,containers).then(function(){return rv;});},handleSaveApply:null,handleSave:null,handleReset:null});
