'use strict';
'require uci';

return L.view.extend({
    load: function() { return uci.load('wizard'); },
    render: function() {
        var m, s, o;
        m = new L.form.Map('wizard', _('البرمجة السريعة'), _('ZTE E8820S'));
        s = m.section(L.form.NamedSection, 'default', 'wizard');

        // وضع التشغيل
        o = s.option(L.form.ListValue, 'wifi_mode', _('وضع التشغيل'));
        o.value('', _('اكسس '));
        o.value('wds_rx', _('WDS مستقبل'));
        o.value('wds_tx', _('WDS مرسل'));
        o.value('mesh_tx', _('Mesh'));
        o.value('pppoe', _('PPPoE'));
       o.default = '';

        o = s.option(L.form.Value, "pppoe_user", _("اسم مستخدم PPPoE")); 
        o.depends("wifi_mode", "pppoe"); 
        o.placeholder = _("اسم المستخدم"); 
        o.rmempty = true; 
        o = s.option(L.form.Value, "pppoe_pass", _("كلمة مرور PPPoE")); 
        o.depends("wifi_mode", "pppoe"); 
        o.password = true; 
        o.rmempty = true;

        o = s.option(L.form.Value, 'special_ssid', _('اسم شبكة الربط'));
        o.depends('wifi_mode', 'wds_rx');
        o.depends('wifi_mode', 'mesh_tx');
        o.placeholder = 'اسم الشبكة المستهدفة';
        o.rmempty = true;

        o = s.option(L.form.Value, 'special_key', _('كلمة سر الربط'));
        o.depends('wifi_mode', 'wds_rx');
        o.depends('wifi_mode', 'mesh_tx');
        o.password = true;
        o.rmempty = true;

        // زر البحث
        o = s.option(L.form.Button, 'scan_wifi', _('بحث عن الشبكات'));
        o.depends('wifi_mode', 'wds_rx');
        o.inputtitle = _('فتح البحث');
        o.onclick = function() {
            window.open('/cgi-bin/scan5g.sh', 'scan5g', 'width=500,height=400');
        };

        
        o = s.option(L.form.Value, 'wifi_ssid', _('اسم الشبكة (2.4G)'));
        o.placeholder = 'MoonLink';
        
        o = s.option(L.form.DummyValue, '_ssid_5g', _('اسم الشبكة (5G)'));
        o.cfgvalue = function(sid) { return (uci.get('wizard', sid, 'wifi_ssid') || 'MoonLink') + '_5G'; };
        
        o = s.option(L.form.Value, 'wifi_key', _('كلمة السر'));
        o.password = true;
        o.rmempty = true;
        
        o = s.option(L.form.Value, 'vlan_id', _('VLAN ID'));
        o.datatype = 'uinteger';
        o.rmempty = true;
        
        o = s.option(L.form.Value, 'lan_ip', _('IP الجهاز'));
        o.datatype = 'ip4addr';

        o = s.option(L.form.Value, 'system_hostname', _('اسم الجهاز (يظهر في النيبوز )'));
        o.placeholder = 'MoonLink';

        o = s.option(L.form.Flag, 'dhcp_enabled', _('"فعل الصح لخيار البروباند "تفعيل DHCP'));
        o.default = '1';

        o = s.option(L.form.ListValue, 'wifi_txpower', _('قوة الإرسال'));
        o.value('default', _('افتراضي'));
        for (var p = 10; p <= 30; p++) o.value(String(p), p + ' dBm');

        // قنوات 2.4 GHz (كلها مدعومة)
        o = s.option(L.form.ListValue, 'ch2g', _('قناة 2.4 GHz'));
        o.value('auto', _('تلقائي'));
        for (var i = 1; i <= 11; i++) { o.value(String(i), i); }

// قنوات 5 GHz (جميع القنوات مع تصنيف الدعم)
o = s.option(L.form.ListValue, 'ch5g', _('قناة 5 GHz'));
o.value('auto', _('تلقائي'));
var all5GChannels = [
    {ch: 36, supported: true}, {ch: 40, supported: true}, {ch: 44, supported: true}, {ch: 48, supported: true},
    {ch: 52, supported: false}, {ch: 56, supported: false}, {ch: 60, supported: false}, {ch: 64, supported: false},
    {ch: 100, supported: false}, {ch: 104, supported: false}, {ch: 108, supported: false}, {ch: 112, supported: false},
    {ch: 116, supported: false}, {ch: 120, supported: false}, {ch: 124, supported: false}, {ch: 128, supported: false},
    {ch: 132, supported: false}, {ch: 136, supported: false}, {ch: 140, supported: false},
    {ch: 149, supported: true}, {ch: 153, supported: true}, {ch: 157, supported: true}, {ch: 161, supported: true}, {ch: 165, supported: true}
];
all5GChannels.forEach(function(item) {
    var label = item.supported ? item.ch + ' (مدعوم)' : item.ch + ' (قد لا تدعمها الهواتف)';
    o.value(String(item.ch), label);
});



        o = s.option(L.form.Flag, 'isreboot', _('إعادة تشغيل دورية'));
        o.rmempty = true;

        o = s.option(L.form.ListValue, 'reboot_h', _('كل كم ساعة'));
        o.depends('isreboot', '1');
        for (var i = 1; i <= 24; i++) o.value(i + 'h', i + ' ساعة');

        o = s.option(L.form.Value, 'password_new', _('كلمة مرور المدير'));
        o.password = true;
        o.rmempty = true;

        return m.render();
    }
});
