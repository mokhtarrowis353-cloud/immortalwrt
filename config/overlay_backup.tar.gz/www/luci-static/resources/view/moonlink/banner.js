'use strict';
'require dom';

return L.Class.extend({
    init: function() {
        var container = document.querySelector('#maincontent .container');
        if (!container) return;
        
        var banner = E('div', { style: 'text-align: center; margin: 10px 0 15px 0;' }, [
            E('a', {
                href: '/cgi-bin/luci/admin/moonlink',
                style: 'display: block; background: linear-gradient(135deg, #4facfe, #00f2fe); color: #fff; text-shadow: 0 0 10px rgba(255,255,255,0.4); padding: 14px 20px; border-radius: 10px; text-decoration: none; font-weight: 700; animation: moonShake 4s infinite, moonPulse 3s infinite;'
            }, [
                E('span', { style: 'font-size: 17px; font-weight: 700;' }, '⚡ البرمجة السريعة'),
                E('span', { style: 'font-size: 11px; opacity: 0.9; margin-right: 8px;' }, '- إعداد سريع للراوتر'),
                E('span', { style: 'float: left; font-size: 16px;' }, '❯')
            ])
        ]);
        
        container.insertBefore(banner, container.firstChild);
        
        var styleSheet = document.createElement("style");
        styleSheet.innerText = `
            @keyframes moonShake {
                0%, 100% { transform: translateX(0); }
                1% { transform: translateX(-4px); }
                2% { transform: translateX(4px); }
                3% { transform: translateX(-4px); }
                4% { transform: translateX(4px); }
                5% { transform: translateX(0); }
            }
            @keyframes moonPulse {
                0%, 100% { 
                    background: linear-gradient(135deg, #4facfe, #00f2fe);
                    box-shadow: 0 0 20px rgba(79, 172, 254, 0.6), 0 0 40px rgba(0, 242, 254, 0.3);
                }
                50% { 
                    background: linear-gradient(135deg, #1a3a4a, #0d7377);
                    box-shadow: 0 0 30px rgba(13, 115, 119, 0.9), 0 0 60px rgba(13, 115, 119, 0.6), 0 0 80px rgba(26, 58, 74, 0.4);
                }
            }
        `;
        document.head.appendChild(styleSheet);
    }
});
